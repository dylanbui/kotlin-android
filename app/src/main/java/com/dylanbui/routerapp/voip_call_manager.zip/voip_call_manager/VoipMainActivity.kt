package com.dylanbui.routerapp.voip_call_manager


import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.dylanbui.android_library.utils.dLog
import org.linphone.core.*
import com.dylanbui.routerapp.R

class VoipMainActivity : AppCompatActivity() {

    private lateinit var mLed: ImageView
    private lateinit var mCoreListener: CoreListenerStub
    private lateinit var mSipAddressToCall: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_main)
        mLed = findViewById(R.id.led)
        // Monitors the registration state of our account(s) and update the LED accordingly
        mCoreListener = object : CoreListenerStub() {
            override fun onRegistrationStateChanged(core: Core, cfg: ProxyConfig, state: RegistrationState, message: String) {
                updateLed(state)
            }
        }
        mSipAddressToCall = findViewById(R.id.address_to_call)
        val callButton = findViewById<Button>(R.id.call_button)
        callButton.setOnClickListener {
            val core: Core? = LinphoneService.core
            val addressToCall = core?.interpretUrl(mSipAddressToCall.getText().toString())
            val params = core?.createCallParams(null)
            val videoEnabled = findViewById<Switch>(R.id.call_with_video)
            params?.enableVideo(videoEnabled.isChecked)
            if (addressToCall != null) {
                core.inviteAddressWithParams(addressToCall, params)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        // Ask runtime permissions, such as record audio and camera
        // We don't need them here but once the user has granted them we won't have to ask again
        checkAndRequestCallPermissions()
    }

    override fun onResume() {
        super.onResume()
        // The best way to use Core listeners in Activities is to add them in onResume
        // and to remove them in onPause
        LinphoneService.core?.addListener(mCoreListener)
        // Manually update the LED registration state, in case it has been registered before
        // we add a chance to register the above listener
        // Update ProxyConfig o day

        val proxyConfig: ProxyConfig? = LinphoneService.core?.defaultProxyConfig
        if (proxyConfig != null) {
            updateLed(proxyConfig.state)
        } else { // No account configured, we display the configuration activity
            startActivity(Intent(this, VoipConfigureAccountActivity::class.java))
        }
    }

    override fun onPause() {
        super.onPause()
        // Like I said above, remove unused Core listeners in onPause
        LinphoneService.core?.removeListener(mCoreListener)
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        // Callback for when permissions are asked to the user
        for (i in permissions.indices) {
            dLog("[Permission] " + permissions[i] + " is "
                        + if (grantResults[i] == PackageManager.PERMISSION_GRANTED) "granted" else "denied"
            )
        }
    }

    private fun updateLed(state: RegistrationState) {
        when (state) {
            RegistrationState.Ok -> mLed!!.setImageResource(R.drawable.ic_voip_led_connected)
            RegistrationState.None, RegistrationState.Cleared -> mLed!!.setImageResource(R.drawable.ic_voip_led_disconnected)
            RegistrationState.Failed -> mLed!!.setImageResource(R.drawable.ic_voip_led_error)
            RegistrationState.Progress -> mLed!!.setImageResource(R.drawable.ic_voip_led_inprogress)
        }
    }

    private fun checkAndRequestCallPermissions() {
        val permissionsList = ArrayList<String>()
        // Some required permissions needs to be validated manually by the user
// Here we ask for record audio and camera to be able to make video calls with sound
// Once granted we don't have to ask them again, but if denied we can
        val recordAudio = packageManager.checkPermission(Manifest.permission.RECORD_AUDIO, packageName)
        dLog("[Permission] Record audio permission is "
                + if (recordAudio == PackageManager.PERMISSION_GRANTED) "granted" else "denied")
        val camera = packageManager.checkPermission(Manifest.permission.CAMERA, packageName)
        dLog("[Permission] Camera permission is "
                    + if (camera == PackageManager.PERMISSION_GRANTED) "granted" else "denied")
        if (recordAudio != PackageManager.PERMISSION_GRANTED) {
            dLog("[Permission] Asking for record audio")
            permissionsList.add(Manifest.permission.RECORD_AUDIO)
        }
        if (camera != PackageManager.PERMISSION_GRANTED) {
            dLog("[Permission] Asking for camera")
            permissionsList.add(Manifest.permission.CAMERA)
        }
        if (permissionsList.size > 0) {
            var permissions: Array<String?>? =
                arrayOfNulls(permissionsList.size)
            permissions = permissionsList.toArray(permissions)
            ActivityCompat.requestPermissions(this, permissions, 0)
        }
    }
}