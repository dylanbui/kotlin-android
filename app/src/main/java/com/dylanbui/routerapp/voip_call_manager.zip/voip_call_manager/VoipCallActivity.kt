package com.dylanbui.routerapp.voip_call_manager

import android.annotation.TargetApi
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.TextureView
import android.view.View
import android.widget.RelativeLayout
import androidx.appcompat.app.AppCompatActivity
import com.dylanbui.routerapp.R
import org.linphone.core.Call
import org.linphone.core.Core
import org.linphone.core.CoreListenerStub
import org.linphone.core.tools.Log
import org.linphone.mediastream.Version

class VoipCallActivity : AppCompatActivity() {

    // We use 2 TextureView, one for remote video and one for local camera preview
    private var mVideoView: TextureView? = null
    private var mCaptureView: TextureView? = null
    private var mCoreListener: CoreListenerStub? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_call)

        mVideoView = findViewById(R.id.videoSurface)
        mCaptureView = findViewById(R.id.videoCaptureSurface)
        val core: Core? = LinphoneService.core
        // We need to tell the core in which to display what
        core?.setNativeVideoWindowId(mVideoView)
        core?.setNativePreviewWindowId(mCaptureView)
        // Listen for call state changes
        mCoreListener = object : CoreListenerStub() {
            override fun onCallStateChanged(core: Core, call: Call, state: Call.State, message: String) {
                if (state == Call.State.End || state == Call.State.Released) {
                    // Once call is finished (end state), terminate the activity
                    // We also check for released state (called a few seconds later) just in case
                    // we missed the first one
                    finish()
                }
            }
        }
        findViewById<View>(R.id.terminate_call).setOnClickListener {
            val core: Core? = LinphoneService.core
            core?.let {
                if (it.callsNb > 0) {
                    var call = it.currentCall
                    if (call == null) { // Current call can be null if paused for example
                        call = it.calls[0]
                    }
                    call.terminate()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
        LinphoneService.core?.addListener(mCoreListener)
        resizePreview()
    }

    override fun onPause() {
        LinphoneService.core?.removeListener(mCoreListener)
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    @TargetApi(24)
    public override fun onUserLeaveHint() { // If the device supports Picture in Picture let's use it
        val supportsPip = packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        Log.i("[Call] Is picture in picture supported: $supportsPip")
        if (supportsPip && Version.sdkAboveOrEqual(24)) {
            enterPictureInPictureMode()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        if (isInPictureInPictureMode) { // Currently nothing to do has we only display video
// But if we had controls or other UI elements we should hide them
        } else { // If we did hide something, let's make them visible again
        }
    }

    private fun resizePreview() {
        val core: Core? = LinphoneService.core
        core == null ?: return

        if (core!!.callsNb > 0) {
            var call = core.currentCall
            if (call == null) {
                call = core.calls[0]
            }
            if (call == null) return
            val metrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(metrics)
            val screenHeight = metrics.heightPixels
            val maxHeight =
                screenHeight / 4 // Let's take at most 1/4 of the screen for the camera preview
            var videoSize = call.currentParams
                .sentVideoDefinition // It already takes care of rotation
            if (videoSize.width == 0 || videoSize.height == 0) {
                Log.w("[Video] Couldn't get sent video definition, using default video definition")
                videoSize = core.preferredVideoDefinition
            }
            var width = videoSize.width
            var height = videoSize.height
            Log.d("[Video] Video height is $height, width is $width")
            width = width * maxHeight / height
            height = maxHeight
            if (mCaptureView == null) {
                Log.e("[Video] mCaptureView is null !")
                return
            }
            val newLp = RelativeLayout.LayoutParams(width, height)
            newLp.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, 1) // Clears the rule, as there is no removeRule until API 17.
            newLp.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, 1)
            mCaptureView!!.layoutParams = newLp
            Log.d("[Video] Video preview size set to " + width + "x" + height)
        }
    }
}