package com.dylanbui.routerapp.voip_call_manager

import com.dylanbui.routerapp.R

import android.app.Service
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.widget.Toast
import org.linphone.core.*
import org.linphone.core.tools.Log
import org.linphone.mediastream.Version
import java.io.File
import java.io.IOException
import java.util.*



class LinphoneService : Service()
{
    private var mHandler: Handler? = null
    private var mTimer: Timer? = null
    private var mCore: Core? = null
    private var mCoreListener: CoreListenerStub? = null

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        // The first call to liblinphone SDK MUST BE to a Factory method
        // So let's enable the library debug logs & log collection
        val basePath = filesDir.absolutePath
        Factory.instance().setLogCollectionPath(basePath)
        Factory.instance().enableLogCollection(LogCollectionState.Enabled)
        Factory.instance().setDebugMode(true, getString(R.string.app_name))

        // Dump some useful information about the device we're running on
        Log.i(START_LINPHONE_LOGS)
        dumpDeviceInformation()
        dumpInstalledLinphoneInformation()

        mHandler = Handler()
        // This will be our main Core listener, it will change activities depending on events
        mCoreListener = object : CoreListenerStub() {
            override fun onCallStateChanged(core: Core, call: Call, state: Call.State, message: String) {
                Toast.makeText(this@LinphoneService, message, Toast.LENGTH_SHORT).show()
                if (state == Call.State.IncomingReceived) {
                    Toast.makeText(
                        this@LinphoneService,
                        "Incoming call received, answering it automatically",
                        Toast.LENGTH_LONG
                    ).show()
                    // For this sample we will automatically answer incoming calls
                    val params = core.createCallParams(call)
                    params.enableVideo(true)
                    call.acceptWithParams(params)
                } else if (state == Call.State.Connected) {
                    // This stats means the call has been established, let's start the call activity
                    val intent = Intent(this@LinphoneService, VoipCallActivity::class.java)
                    // As it is the Service that is starting the activity, we have to give this flag
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                }
            }
        }
        try {
            // Let's copy some RAW resources to the device
            // The default config file must only be installed once (the first time)
            copyIfNotExist(R.raw.linphonerc_default, "$basePath/.linphonerc")
            // The factory config is used to override any other setting, let's copy it each time
            copyFromPackage(R.raw.linphonerc_factory, "linphonerc")

        } catch (ioe: IOException) {
            Log.e(ioe)
        }

        // Create the Core and add our listener
        mCore = Factory.instance().createCore("$basePath/.linphonerc", "$basePath/linphonerc", this)
        mCore?.addListener(mCoreListener)
        // Core is ready to be configured
        configureCore()
    }

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        // If our Service is already running, no need to continue
        if (instance != null) {
            return START_STICKY
        }
        // Our Service has been started, we can keep our reference on it
// From now one the Launcher will be able to call onServiceReady()
        instance = this
        // Core must be started after being created and configured
        mCore!!.start()
        // We also MUST call the iterate() method of the Core on a regular basis
        val lTask: TimerTask = object : TimerTask() {
            override fun run() {
                mHandler!!.post {
                    if (mCore != null) {
                        mCore!!.iterate()
                    }
                }
            }
        }
        mTimer = Timer("Linphone scheduler")
        mTimer!!.schedule(lTask, 0, 20)
        return START_STICKY
    }

    override fun onDestroy() {
        mCore!!.removeListener(mCoreListener)
        mTimer!!.cancel()
        mCore!!.stop()
        // A stopped Core can be started again
// To ensure resources are freed, we must ensure it will be garbage collected
        mCore = null
        // Don't forget to free the singleton as well
        instance = null
        super.onDestroy()
    }

    override fun onTaskRemoved(rootIntent: Intent) { // For this sample we will kill the Service at the same time we kill the app
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun configureCore() { // We will create a directory for user signed certificates if needed
        val basePath = filesDir.absolutePath
        val userCerts = "$basePath/user-certs"
        val f = File(userCerts)
        if (!f.exists()) {
            if (!f.mkdir()) {
                Log.e("$userCerts can't be created.")
            }
        }
        mCore!!.userCertificatesPath = userCerts
    }

    private fun dumpDeviceInformation() {
        val sb = StringBuilder()
        sb.append("DEVICE=").append(Build.DEVICE).append("\n")
        sb.append("MODEL=").append(Build.MODEL).append("\n")
        sb.append("MANUFACTURER=").append(Build.MANUFACTURER).append("\n")
        sb.append("SDK=").append(Build.VERSION.SDK_INT).append("\n")
        sb.append("Supported ABIs=")
        for (abi in Version.getCpuAbis()) {
            sb.append(abi).append(", ")
        }
        sb.append("\n")
        Log.i(sb.toString())
    }

    private fun dumpInstalledLinphoneInformation() {
        var info: PackageInfo? = null
        try {
            info = packageManager.getPackageInfo(packageName, 0)
        } catch (nnfe: PackageManager.NameNotFoundException) {
            Log.e(nnfe)
        }
        if (info != null) {
            Log.i(
                "[Service] Linphone version is ",
                info.versionName + " (" + info.versionCode + ")"
            )
        } else {
            Log.i("[Service] Linphone version is unknown")
        }
    }

    @Throws(IOException::class)
    private fun copyIfNotExist(ressourceId: Int, target: String) {
        val lFileToCopy = File(target)
        if (!lFileToCopy.exists()) {
            copyFromPackage(ressourceId, lFileToCopy.name)
        }
    }

    @Throws(IOException::class)
    private fun copyFromPackage(ressourceId: Int, target: String) {
        val lOutputStream = openFileOutput(target, 0)
        val lInputStream = resources.openRawResource(ressourceId)
        var readByte: Int
        val buff = ByteArray(8048)
        while (lInputStream.read(buff).also { readByte = it } != -1) {
            lOutputStream.write(buff, 0, readByte)
        }
        lOutputStream.flush()
        lOutputStream.close()
        lInputStream.close()
    }

    companion object {
        private const val START_LINPHONE_LOGS = " ==== Device information dump ===="
        // Keep a static reference to the Service so we can access it from anywhere in the app
        var instance: LinphoneService? = null
            private set

        val isReady: Boolean
            get() = instance != null

        val core: Core?
            get() = instance!!.mCore
    }
}