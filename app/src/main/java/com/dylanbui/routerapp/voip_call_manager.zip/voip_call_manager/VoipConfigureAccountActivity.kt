package com.dylanbui.routerapp.voip_call_manager

import com.dylanbui.routerapp.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.linphone.core.*


class VoipConfigureAccountActivity : AppCompatActivity() {

    private lateinit var mUsername: EditText
    private lateinit var mPassword: EditText
    private lateinit var mDomain: EditText
    private lateinit var mTransport: RadioGroup
    private lateinit var mConnect: Button
    private lateinit var mAccountCreator: AccountCreator
    private lateinit var mCoreListener: CoreListenerStub

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_voip_configure_account)
        // Account creator can help you create/config accounts, even not sip.linphone.org ones
// As we only want to configure an existing account, no need for server URL to make requests
// to know whether or not account exists, etc...

        // LinphoneService.core?.createAddress(proxy) // Tao proxy o day

        mAccountCreator = LinphoneService.core?.createAccountCreator(null)!!
        mUsername = findViewById(R.id.username)
        mPassword = findViewById(R.id.password)
        mDomain = findViewById(R.id.domain)
        mTransport = findViewById(R.id.assistant_transports)
        mConnect = findViewById(R.id.configure)
        mConnect.setOnClickListener(View.OnClickListener { configureAccount() })
        mCoreListener = object : CoreListenerStub() {
            override fun onRegistrationStateChanged(core: Core, cfg: ProxyConfig, state: RegistrationState, message: String) {
                if (state == RegistrationState.Ok) {
                    finish()
                } else if (state == RegistrationState.Failed) {
                    Toast.makeText(this@VoipConfigureAccountActivity, "Failure: $message", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
        LinphoneService.core?.addListener(mCoreListener)
    }

    override fun onPause() {
        LinphoneService.core?.removeListener(mCoreListener)
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun configureAccount() { // At least the 3 below values are required
        mAccountCreator.username = mUsername!!.text.toString()
        mAccountCreator.domain = mDomain!!.text.toString()
        mAccountCreator.password = mPassword!!.text.toString()

        when (mTransport.checkedRadioButtonId) {
            R.id.transport_udp -> mAccountCreator.transport = TransportType.Udp
            R.id.transport_tcp -> mAccountCreator.transport = TransportType.Tcp
            R.id.transport_tls -> mAccountCreator.transport = TransportType.Tls
        }



        // This will automatically create the proxy config and auth info and add them to the Core
        var cfg: ProxyConfig = mAccountCreator.createProxyConfig()
        // Make sure the newly created one is the default
        LinphoneService.core?.defaultProxyConfig = cfg

//        val add: Address = LinphoneService.core?.createAddress("asada")
//        mAccountCreator = LinphoneService.core?.createAccountCreator(null)
//        LinphoneService.core?.createProxyConfig("", "", null, true)

//        var cfgaaa: ProxyConfig = LinphoneService.core?.createProxyConfig()!!

//        LinphoneService.core?.createAuthInfo()


    }
}